package questionTest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class OpSqliteDB {
	
	private static final String Class_Name = "org.sqlite.JDBC";
    private static final String DB_URL = "jdbc:sqlite:D:\\\\DownloadFiles\\\\Sqlite\\\\TriviaMazeQuestion.db";
    private static Connection connection = null;

	public static void main(String[] args) {
		
		try {
            connection = createConnection();
            System.out.println("Make connection");
            
            //The corresponding method can be called according to the required type of data
            List<Question> list1=getMultipleChoice();
            for(int i=0;i<list1.size();i++) {
            	System.out.println(list1.get(i));
            }
            
            System.out.println("Success!");
        }  catch (SQLException e) {
            System.err.println(e.getMessage());
        } catch(Exception e) {
            e.printStackTrace();
        } finally{
            try {
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                // connection close failed.
                System.err.println(e);
            }
        }
	}
	// Create Sqlite database connect
    public static Connection createConnection() throws SQLException, ClassNotFoundException {
        Class.forName(Class_Name);
        return DriverManager.getConnection(DB_URL);
    }
    
    public static List<Question> getTrueOrFalse() throws SQLException {
    	List<Question> list=new ArrayList<Question>();
        Statement statement = connection.createStatement();
        statement.setQueryTimeout(30);
        // Execute query
        ResultSet rs = statement.executeQuery("select * from TrueOrFalse");
        while (rs.next()) {
            Integer id = Integer.parseInt(rs.getString("id"));
            String question = rs.getString("question");
            String answer = rs.getString("answer");
            Question q=new Question(id, question, answer);
            list.add(q);
        }
        return list;
    }
    
    public static List<Question> getOneWord() throws SQLException {
    	List<Question> list=new ArrayList<Question>();
        Statement statement = connection.createStatement();
        statement.setQueryTimeout(30);
        // Execute query
        ResultSet rs = statement.executeQuery("select * from OneWord");
        while (rs.next()) {
            Integer id = Integer.parseInt(rs.getString("id"));
            String question = rs.getString("question");
            String answer = rs.getString("answer");
            Question q=new Question(id, question, answer);
            list.add(q);
        }
        return list;
    }
    
    public static List<Question> getMultipleChoice() throws SQLException {
    	List<Question> list=new ArrayList<Question>();
        Statement statement = connection.createStatement();
        statement.setQueryTimeout(30);
        // Execute query
        ResultSet rs = statement.executeQuery("select * from MultipleChoice");
        while (rs.next()) {
            Integer id = Integer.parseInt(rs.getString("id"));
            String question = rs.getString("question");
            String answer = rs.getString("answer");
            Question q=new Question(id, question, answer);
            list.add(q);
        }
        return list;
    }
    
}
