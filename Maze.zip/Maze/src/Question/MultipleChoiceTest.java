package Question;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MultipleChoiceTest {

//	@Test
//	void test() {
//		JunitTesting test = new JunitTesting();
//		int output = test.
//	}

}
